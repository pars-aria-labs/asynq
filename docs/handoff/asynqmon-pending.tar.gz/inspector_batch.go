package asynqmon

import (
	"context"
	"github.com/gorilla/mux"
	"github.com/hibiken/asynq"
	"net/http"
	"strconv"
	"time"
)

// Optional interfaces keep builds compatible with the published dependency.
// A local workspace or a release containing these APIs activates the fast path.
type queueBatchInspector interface {
	GetQueueInfoBatch(context.Context, []string, time.Duration) ([]*asynq.QueueInfo, error)
}
type taskBatchInspector interface {
	ProcessTaskBatch(context.Context, string, string, string, string, int) (int, int, error)
}

func getQueueInfos(ctx context.Context, inspector *asynq.Inspector, queues []string) ([]*asynq.QueueInfo, error) {
	if batch, ok := any(inspector).(queueBatchInspector); ok {
		return batch.GetQueueInfoBatch(ctx, queues, 15*time.Second)
	}
	infos := make([]*asynq.QueueInfo, 0, len(queues))
	for _, q := range queues {
		info, err := inspector.GetQueueInfo(q)
		if err != nil {
			return nil, err
		}
		infos = append(infos, info)
	}
	return infos, nil
}
func getQueueInfo(ctx context.Context, inspector *asynq.Inspector, queue string) (*asynq.QueueInfo, error) {
	infos, err := getQueueInfos(ctx, inspector, []string{queue})
	if err != nil {
		return nil, err
	}
	return infos[0], nil
}

// Existing endpoints retain their response fields and gain an optional bounded
// mode. Each request is independent and respects its HTTP cancellation context.
func serveTaskBatch(w http.ResponseWriter, r *http.Request, inspector *asynq.Inspector, state, action string) bool {
	raw := r.URL.Query().Get("batch_size")
	if raw == "" {
		return false
	}
	limit, err := strconv.Atoi(raw)
	if err != nil || limit < 1 || limit > 500 {
		http.Error(w, "batch_size must be between 1 and 500", http.StatusBadRequest)
		return true
	}
	batch, ok := any(inspector).(taskBatchInspector)
	if !ok {
		return false
	}
	vars := mux.Vars(r)
	n, remaining, err := batch.ProcessTaskBatch(r.Context(), vars["qname"], state, action, vars["gname"], limit)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return true
	}
	field := map[string]string{"delete": "deleted", "run": "scheduled", "archive": "archived"}[action]
	writeResponseJSON(w, map[string]int{field: n, "remaining": remaining})
	return true
}
