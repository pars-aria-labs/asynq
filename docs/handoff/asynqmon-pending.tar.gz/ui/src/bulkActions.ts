import request from "./request";

export interface BulkProgress { id: number; action: string; processed: number; total?: number }
let sequence = 0;
const active = new Map<number, BulkProgress>();
const listeners = new Set<() => void>();
let snapshot: BulkProgress[] = [];
function notify() { snapshot = [...active.values()]; listeners.forEach(listener => listener()); }
export function subscribeBulkProgress(listener: () => void) { listeners.add(listener); return () => { listeners.delete(listener); }; }
export function getBulkProgress() { return snapshot; }

export async function performBulkAction(action: "delete" | "run" | "archive", url: string): Promise<number> {
 const id = ++sequence;
 let processed = 0;
 let budget: number | undefined;
 active.set(id, { id, action, processed }); notify();
 try {
  while (budget === undefined || processed < budget) {
   const limit = Math.min(500, budget === undefined ? 500 : budget - processed);
   const { data } = await request<Record<string, number>>({ method: action === "delete" ? "delete" : "post", url, params: { batch_size: limit } });
   const field = { delete: "deleted", run: "scheduled", archive: "archived" }[action];
   const n = data[field];
   const remaining = data.remaining;
   // Older servers execute the complete operation and omit remaining.
   if (!Number.isSafeInteger(n) || n < 0 || (remaining !== undefined && (!Number.isSafeInteger(remaining) || remaining < 0 || n > limit))) throw new Error("Invalid bulk operation response");
   processed += n;
   if (remaining === undefined) return processed;
   if (budget === undefined) budget = processed + remaining;
   active.set(id, { id, action, processed, total: budget }); notify();
   if (remaining === 0 || n === 0) break;
  }
  return processed;
 } catch (error) {
  // Never retry mutations automatically: a lost reply can follow a successful batch.
  const message = error instanceof Error ? error.message : String(error);
  throw new Error(`Operation stopped after ${processed} confirmed tasks. ${message}`);
 } finally { active.delete(id); notify(); }
}
