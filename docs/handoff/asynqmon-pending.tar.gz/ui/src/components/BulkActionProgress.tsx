import { useSyncExternalStore } from "react";
import { Box, LinearProgress, Paper, Typography } from "@mui/material";
import { getBulkProgress, subscribeBulkProgress } from "../bulkActions";

export default function BulkActionProgress() {
 const operations = useSyncExternalStore(subscribeBulkProgress, getBulkProgress, getBulkProgress);
 if (!operations.length) return null;
 return <Box sx={{ position: "fixed", right: 16, bottom: 80, zIndex: 1500, width: 320, maxWidth: "calc(100vw - 32px)" }}>
  {operations.map(op => <Paper key={op.id} role="status" aria-live="polite" sx={{ p: 2, mt: 1 }}>
   <Typography variant="body2">{{ delete: "Deleting tasks", run: "Scheduling tasks", archive: "Archiving tasks" }[op.action]}: {op.processed.toLocaleString()}{op.total !== undefined ? ` / ${op.total.toLocaleString()}` : ""}</Typography>
   <LinearProgress sx={{ mt: 1 }} variant={op.total ? "determinate" : "indeterminate"} value={op.total ? Math.min(100, 100 * op.processed / op.total) : undefined} />
  </Paper>)}
 </Box>;
}
