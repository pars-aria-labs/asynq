import { beforeEach, describe, expect, it, vi } from "vitest";
import request from "./request";
import { getBulkProgress, performBulkAction } from "./bulkActions";
vi.mock("./request", () => ({ default: vi.fn() }));
const mocked = vi.mocked(request);
beforeEach(() => mocked.mockReset());
describe("bulk operations", () => {
 it("caps work despite a growing remaining count and reports total deletions", async () => {
  mocked.mockResolvedValueOnce({ data: { deleted: 500, remaining: 20 } } as any)
    .mockResolvedValueOnce({ data: { deleted: 20, remaining: 5000 } } as any);
  expect(await performBulkAction("delete", "/tasks")).toBe(520);
  expect(mocked.mock.calls.map(([config]) => config.params.batch_size)).toEqual([500, 20]);
  expect(getBulkProgress()).toEqual([]);
 });
 it("supports old server responses without repeating a mutation", async () => {
  mocked.mockResolvedValueOnce({ data: { scheduled: 1200 } } as any);
  expect(await performBulkAction("run", "/tasks")).toBe(1200);
  expect(mocked).toHaveBeenCalledTimes(1);
 });
 it("does not retry a failed batch and clears progress", async () => {
  mocked.mockResolvedValueOnce({ data: { archived: 500, remaining: 1 } } as any)
    .mockRejectedValueOnce(new Error("connection lost"));
  await expect(performBulkAction("archive", "/tasks")).rejects.toThrow("500 confirmed tasks");
  expect(mocked).toHaveBeenCalledTimes(2);
  expect(getBulkProgress()).toEqual([]);
 });
 it("stops when concurrent consumers empty the queue", async () => {
  mocked.mockResolvedValueOnce({ data: { deleted: 0, remaining: 10 } } as any);
  expect(await performBulkAction("delete", "/tasks")).toBe(0);
  expect(mocked).toHaveBeenCalledTimes(1);
 });
});
