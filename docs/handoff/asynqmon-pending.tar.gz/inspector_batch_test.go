package asynqmon

import (
	"net/http/httptest"
	"testing"
)

func TestServeTaskBatchRejectsInvalidLimit(t *testing.T) {
	for _, limit := range []string{"0", "-1", "501", "abc"} {
		w := httptest.NewRecorder()
		r := httptest.NewRequest("POST", "/queues/default/scheduled_tasks:run_all?batch_size="+limit, nil)
		if !serveTaskBatch(w, r, nil, "scheduled", "run") || w.Code != 400 {
			t.Fatalf("limit %q: status %d", limit, w.Code)
		}
	}
}
